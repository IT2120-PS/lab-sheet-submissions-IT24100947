setwd("C:\\Users\\it24100947\\Desktop\\IT24100947\\Lab_Sheet04")
getwd()

# 1. Question1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
attach(branch_data)

# 2. Question2
str(branch_data)

# 3. Question3
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales", ylab = "Sales (in millions)", col = "lightblue")

# 4. Question4
summary_stats <- summary(branch_data$Advertising_X2)
iqr_advertising <- IQR(branch_data$Advertising_X2)
cat("Five-number summary for Advertising_X2:\n", 
    "Min:", summary_stats[1], 
    "Q1:", summary_stats[2], 
    "Median:", summary_stats[3], 
    "Q3:", summary_stats[5], 
    "Max:", summary_stats[6], "\n")
cat("IQR for Advertising_X2:", iqr_advertising, "\n")

# 5. Question5
find_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}


years_outliers <- find_outliers(branch_data$Years_X3)
if (length(years_outliers) == 0) {
  cat("No outliers in Years_X3\n")
} else {
  cat("Outliers in Years_X3:", years_outliers, "\n")
}